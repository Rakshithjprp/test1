#!/bin/bash

date
epoch_time=$(date +%s)
echo $epoch_time